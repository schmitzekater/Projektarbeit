<html>	
<head>	
	<?php include'menu.php'?>
</head>
<body>
<div id="scroller">
<div id="content">
		<h1>Impressum</h1>
		<p>Diese Praxis ist rein virtuell. </p>
		<p>Erstellt f&uuml;r das Fach Programmieren 2 an der HS-Ulm.</p>
		<h2>Hochschule Ulm</h2>
		<h4>University of applied sciences</h4>
		<p>Prittwitzstr. 10<br>89075 Ulm<br>Deutschland<br>Fon: +49(0731)50-208</p>
		<h2>Autoren</h2>
		<ul>
			<li>Sophie Knahl <em>Controlling</em>
			<li>Nadine Lassotta <em>Design</em>
			<li>Christina Lutzev <em>Consulting</em>
			<li>Alexander Schmitz <em>Coding</em>
</div>
</div>
</body>
</html>