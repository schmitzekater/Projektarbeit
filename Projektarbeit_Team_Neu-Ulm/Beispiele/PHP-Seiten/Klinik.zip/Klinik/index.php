<html>	
<head>	
	<?php include'menu.php'?>
</head>
<body>
<div id="scroller">
<div id="content">
		<h2>Herzlich willkommen bei der Tierarztpraxis Dr. Hasefuss
		<h3>Leitung: Dr. vet. med. Alois Mindermind</h3>
		<p>Unsere &Ouml;ffnungszeiten:</p>
			<table cellspacing="5" cellpadding="5">
				<tr>
					<td>Mo + Di</td>
					<td>08:00 - 12:00 und 14:00 - 17:00</td>
				</tr>
				<tr>
					<td>Mi</td>
					<td>08:00 - 13:00 (nachmittags geschlossen)</td>
				</tr>
				<tr>
					<td>Do</td>
					<td>08:00 - 12:00 und 14:00 - 19:30</td>
				</tr>
				<tr>
					<td>Fr</td>
					<td>08:00 - 12:00 und 13:00 - 16:00</td>
				</tr>
			</table>
		<p><td>Individuelle Sprechzeiten nach R�cksprache.</p>
</div>
</div>
</body>
</html>