<html>	
<head>	
	<?php include'menu.php'?>
</head>
<body>
<div id="scroller">
<div id="content">
		<h1>Impressum</h1>
		<p>Diese Praxis ist rein virtuell. </p>
		<p>Erstellt f&uuml;r das Fach Programmieren 2 an der HS-Ulm.</p>
		<h2>Autoren</h2>
		<ul>
			<li>Sophie Knahl <em>Controlling</em>
			<li>Nadine Lassotta <em>Design</em>
			<li>Christina Lutzev <em>Consulting</em>
			<li>Alexander Schmitz <em>Coding</em>
</div>
</div>
</body>
</html>